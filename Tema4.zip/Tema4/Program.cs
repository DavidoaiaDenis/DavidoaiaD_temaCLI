﻿using OpenTK;
using OpenTK.Graphics;
using OpenTK.Graphics.OpenGL;
using OpenTK.Input;
using System;
using System.Collections.Generic;

namespace Tema4_Modificat
{
    public class CustomGame : GameWindow
    {
        private List<Cube> cubeList = new List<Cube>();
        private Random randomizer = new Random();

        private bool showGrid = true;
        private Color4 currentBackground = Color4.MediumPurple;
        private Vector3 cameraPos = new Vector3(4, 4, 4);
        private float movementSpeed = 0.6f;
        private float fallSpeed = 9.8f;

        public CustomGame() : base(800, 600, GraphicsMode.Default, "Modified 3D Cube Game")
        {
            VSync = VSyncMode.On;
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            GL.ClearColor(currentBackground);
            GL.Enable(EnableCap.DepthTest);

            Matrix4 projection = Matrix4.CreatePerspectiveFieldOfView(
                MathHelper.DegreesToRadians(50f),
                (float)Width / Height,
                0.1f,
                100f);
            GL.MatrixMode(MatrixMode.Projection);
            GL.LoadMatrix(ref projection);

            ShowMenu();
        }

        private void ShowMenu()
        {
            Console.Clear();
            Console.WriteLine("Meniu:");
            Console.WriteLine("ESC - Iesire");
            Console.WriteLine("J   - Schimba culoarea fundalului");
            Console.WriteLine("V   - Afiseaza/Ascunde grid-ul");
            Console.WriteLine("G   - Activeaza/Dezactiveaza gravitatia");
            Console.WriteLine("Click stanga - Adauga un cub");
            Console.WriteLine("Click dreapta - Elimina toate cuburile");
            Console.WriteLine("W, A, S, D   - Miscare camera");
        }

        protected override void OnUpdateFrame(FrameEventArgs e)
        {
            base.OnUpdateFrame(e);

            var keyState = Keyboard.GetState();
            if (keyState.IsKeyDown(Key.W)) cameraPos.X -= movementSpeed;
            if (keyState.IsKeyDown(Key.S)) cameraPos.X += movementSpeed;
            if (keyState.IsKeyDown(Key.A)) cameraPos.Z += movementSpeed;
            if (keyState.IsKeyDown(Key.D)) cameraPos.Z -= movementSpeed;

            if (keyState.IsKeyDown(Key.J))
            {
                ChangeBackground();
                ShowMenu();
            }

            if (keyState.IsKeyDown(Key.G))
            {
                fallSpeed = fallSpeed == 9.8f ? 0f : 9.8f;
            }

            float delta = (float)e.Time;
            foreach (var cube in cubeList)
            {
                cube.Update(delta, fallSpeed);
            }
        }

        protected override void OnMouseDown(MouseButtonEventArgs e)
        {
            base.OnMouseDown(e);

            if (e.Button == MouseButton.Left)
            {
                AddCube();
            }
            else if (e.Button == MouseButton.Right)
            {
                cubeList.Clear();
                Console.WriteLine("Toate cuburile au fost eliminate.");
            }
        }

        private void AddCube()
        {
            var cube = new Cube(
                new Vector3(
                    (float)(randomizer.NextDouble() * 2.0 - 1.0),
                    (float)(randomizer.NextDouble() * 4.0 + 2.0),
                    (float)(randomizer.NextDouble() * 2.0 - 1.0)
                ),
                (float)(randomizer.NextDouble() * 0.6 + 0.4),
                new Color4(
                    (float)randomizer.NextDouble(),
                    (float)randomizer.NextDouble(),
                    (float)randomizer.NextDouble(),
                    1.0f
                )
            );
            cubeList.Add(cube);
        }

        private void ChangeBackground()
        {
            currentBackground = new Color4(
                (float)randomizer.NextDouble(),
                (float)randomizer.NextDouble(),
                (float)randomizer.NextDouble(),
                1.0f);
            GL.ClearColor(currentBackground);
            Console.WriteLine("Fundal schimbat: " + currentBackground);
        }

        protected override void OnRenderFrame(FrameEventArgs e)
        {
            base.OnRenderFrame(e);

            GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);

            Matrix4 modelview = Matrix4.LookAt(cameraPos, Vector3.Zero, Vector3.UnitY);
            GL.MatrixMode(MatrixMode.Modelview);
            GL.LoadMatrix(ref modelview);

            DrawCoordinateAxes();

            if (showGrid)
            {
                RenderGrid();
            }

            foreach (var cube in cubeList)
            {
                cube.Draw();
            }

            SwapBuffers();
        }

        private void DrawCoordinateAxes()
        {
            GL.Begin(PrimitiveType.Lines);

            GL.Color3(1.0f, 0.0f, 0.0f); // X - roșu
            GL.Vertex3(0, 0, 0);
            GL.Vertex3(6, 0, 0);

            GL.Color3(0.0f, 1.0f, 0.0f); // Y - verde
            GL.Vertex3(0, 0, 0);
            GL.Vertex3(0, 6, 0);

            GL.Color3(0.0f, 0.0f, 1.0f); // Z - albastru
            GL.Vertex3(0, 0, 0);
            GL.Vertex3(0, 0, 6);

            GL.End();
        }

        private void RenderGrid(int size = 8, float spacing = 1.2f)
        {
            GL.Color3(0.8f, 0.8f, 0.8f);
            GL.Begin(PrimitiveType.Lines);

            for (int i = -size; i <= size; i++)
            {
                GL.Vertex3(i * spacing, 0, -size * spacing);
                GL.Vertex3(i * spacing, 0, size * spacing);

                GL.Vertex3(-size * spacing, 0, i * spacing);
                GL.Vertex3(size * spacing, 0, i * spacing);
            }

            GL.End();
        }

        [STAThread]
        public static void Main()
        {
            using (var game = new CustomGame())
            {
                game.Run(60.0);
            }
        }
    }

    public class Cube
    {
        public Vector3 Position { get; private set; }
        private float Size { get; set; }
        private Color4 CubeColor { get; set; }

        public Cube(Vector3 position, float size, Color4 color)
        {
            Position = position;
            Size = size;
            CubeColor = color;
        }

        public void Update(float deltaTime, float gravity)
        {
            if (Position.Y > 0)
            {
                Position -= new Vector3(0, deltaTime * gravity, 0);
                if (Position.Y < 0)
                {
                    Position = new Vector3(Position.X, 0, Position.Z);
                }
            }
        }

        public void Draw()
        {
            GL.PushMatrix();
            GL.Translate(Position);
            GL.Scale(Size * 1.2f, Size * 1.2f, Size * 1.2f); // Cub mai mare
            GL.Color4(CubeColor);

            GL.Begin(PrimitiveType.Quads);
            // Fațetele cubului (mai mari și cu o altă ordine)

            // Fața frontală
            GL.Vertex3(-1.0f, -1.0f, 1.0f);
            GL.Vertex3(1.0f, -1.0f, 1.0f);
            GL.Vertex3(1.0f, 1.0f, 1.0f);
            GL.Vertex3(-1.0f, 1.0f, 1.0f);

            // Fața spate
            GL.Vertex3(-1.0f, -1.0f, -1.0f);
            GL.Vertex3(-1.0f, 1.0f, -1.0f);
            GL.Vertex3(1.0f, 1.0f, -1.0f);
            GL.Vertex3(1.0f, -1.0f, -1.0f);

            // Fața de sus
            GL.Vertex3(-1.0f, 1.0f, -1.0f);
            GL.Vertex3(-1.0f, 1.0f, 1.0f);
            GL.Vertex3(1.0f, 1.0f, 1.0f);
            GL.Vertex3(1.0f, 1.0f, -1.0f);

            // Fața de jos
            GL.Vertex3(-1.0f, -1.0f, -1.0f);
            GL.Vertex3(1.0f, -1.0f, -1.0f);
            GL.Vertex3(1.0f, -1.0f, 1.0f);
            GL.Vertex3(-1.0f, -1.0f, 1.0f);

            // Fața dreapta
            GL.Vertex3(1.0f, -1.0f, -1.0f);
            GL.Vertex3(1.0f, 1.0f, -1.0f);
            GL.Vertex3(1.0f, 1.0f, 1.0f);
            GL.Vertex3(1.0f, -1.0f, 1.0f);

            // Fața stânga
            GL.Vertex3(-1.0f, -1.0f, 1.0f);
            GL.Vertex3(-1.0f, 1.0f, 1.0f);
            GL.Vertex3(-1.0f, 1.0f, -1.0f);
            GL.Vertex3(-1.0f, -1.0f, -1.0f);

            GL.End();
            GL.PopMatrix();
        }

    }
}
